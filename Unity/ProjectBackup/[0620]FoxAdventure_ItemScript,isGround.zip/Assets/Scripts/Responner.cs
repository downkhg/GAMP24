using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Responner : MonoBehaviour
{
    float maxTime;
    float curTime = -1;

    public GameObject prefabPlayer;
    public GameObject objPlayer;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (curTime >= 0)
        {
            if (curTime < maxTime)
            {
                curTime += Time.deltaTime;
            }
            else
            {
                objPlayer = Instantiate(prefabPlayer, transform.position, Quaternion.identity);
                curTime = -1;
            }
        }

        if(objPlayer ==  null)
        {
            curTime = 0;
        }
    }
}
